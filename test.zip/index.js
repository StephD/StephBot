import 'dotenv/config';
import express from 'express';
import {
  InteractionType,
  InteractionResponseType,
  InteractionResponseFlags,
  MessageComponentTypes,
  verifyKeyMiddleware,
} from 'discord-interactions';

// Create an express app
const app = express();
// Get port, or default to 3000
const PORT = process.env.PORT || 3000;

/**
 * This is the simplest example of a Discord bot with a /hello command
 * The only environment variable you need is PUBLIC_KEY from your Discord application
 */

// Handle Discord interactions
app.post('/interactions', verifyKeyMiddleware(process.env.PUBLIC_KEY), async function (req, res) {
  // Get interaction data
  const { type, data } = req.body;

  // Handle verification request (PING)
  if (type === InteractionType.PING) {
    return res.send({ type: InteractionResponseType.PONG });
  }

  // Handle slash command
  if (type === InteractionType.APPLICATION_COMMAND) {
    const { name } = data;

    // /hello command implementation
    if (name === 'hello') {
      return res.send({
        type: InteractionResponseType.CHANNEL_MESSAGE_WITH_SOURCE,
        data: {
          flags: InteractionResponseFlags.IS_COMPONENTS_V2,
          components: [
            {
              type: MessageComponentTypes.TEXT_DISPLAY,
              content: `👋 Hello! This is a basic Discord bot response.`
            }
          ]
        },
      });
    }

    // Handle unknown commands
    return res.status(400).json({ error: 'unknown command' });
  }

  // Handle unknown interaction types
  return res.status(400).json({ error: 'unknown interaction type' });
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 Bot is running on port ${PORT}`);
  console.log(`✅ Use "/hello" to test the command`);
});

/**
 * To register this command with Discord, create a commands.js file with:
 * 
 * const HELLO_COMMAND = {
 *   name: 'hello',
 *   description: 'Simple hello command',
 *   type: 1,
 *   integration_types: [0, 1],
 *   contexts: [0, 1, 2],
 * };
 * 
 * InstallGlobalCommands(process.env.APP_ID, [HELLO_COMMAND]);
 */
